package guru.springframework.sfgpetclinic.services;

import guru.springframework.sfgpetclinic.model.PetType;

/**
 * Created by jt on 7/29/18.
 */
public interface PetTypeService extends CrudService<PetType, Long> {
}
