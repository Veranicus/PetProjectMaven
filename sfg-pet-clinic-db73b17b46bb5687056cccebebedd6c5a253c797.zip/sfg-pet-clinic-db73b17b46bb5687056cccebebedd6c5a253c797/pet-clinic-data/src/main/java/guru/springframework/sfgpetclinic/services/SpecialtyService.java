package guru.springframework.sfgpetclinic.services;

import guru.springframework.sfgpetclinic.model.Speciality;

/**
 * Created by jt on 7/31/18.
 */
public interface SpecialtyService extends CrudService<Speciality, Long> {
}
